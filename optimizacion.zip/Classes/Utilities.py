def is_even(num):
    """
    :param num: Le llega un numero y devuelve si es par o no
    :return: bool
    """
    if num % 2 == 0:
        return True
    else:
        return False
